﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
 /// <summary>
namespace wpf_panels
{
   
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void login_btn_Click(object sender, RoutedEventArgs e)
        {
            /*
             * This function validates a user.
             */

            string wrong_password_msg = "You have entered the wrong password or username! Try again";
            string right_password_msg = "Welcome";

            //Available passwords
            string[] passwords = { "dog", "cat", "car", "plane"};

            string username = this.username_box.Text;
            string password = this.password_box.Password; // Get the password

            // Check if the password is correct
            if ((passwords.Contains(password) == true) && (username == "sydney"))
            {
                //Welcome Message
                MessageBox.Show(right_password_msg + " " + username);

                //Show the other controls
                this.expenses_label.Visibility = System.Windows.Visibility.Visible;
                this.gross_sal_label.Visibility = System.Windows.Visibility.Visible;
                this.gross_sal_box.Visibility = System.Windows.Visibility.Visible;
                this.tax_box.Visibility = System.Windows.Visibility.Visible;
                this.tax_label.Visibility = System.Windows.Visibility.Visible;
                this.other_exp_label.Visibility = System.Windows.Visibility.Visible;
                this.other_exp_box.Visibility = System.Windows.Visibility.Visible;
                this.compute_savings_btn.Visibility = System.Windows.Visibility.Visible;
            }
            else
            {
                MessageBox.Show(wrong_password_msg);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //Compute savings
            double savings;
            double gross_sal = Double.Parse(this.gross_sal_box.Text);
            double tax = Double.Parse(this.tax_box.Text);
            double other_exp = Double.Parse(this.other_exp_box.Text);
            savings = gross_sal - tax - other_exp;

            //Diplsay savings
            this.savings_amount_label.Visibility = System.Windows.Visibility.Visible;
            this.saving_amount.Content = savings.ToString();
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
 
    
    }
}
