﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace link_custom_class
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void create_account_btn_Click(object sender, RoutedEventArgs e)
        {
            string disp_bank_name = this.bank_name.Text;
            //string disp_acc_type = this.acc_type.;   // Find out how to get content from combobox items
            string disp_acc_name = this.acc_name.Text;
            double deposit = Double.Parse(this.deposit.Text); // Do the validation by yourself

            //Test some objects from the Account class
            Account acc_1 = new Account("Cheque", disp_acc_name, disp_bank_name, deposit);

            //Display some stuff
            this.show_account_name.Content = acc_1.showAccountName();
            this.show_bank_name.Content = acc_1.showBankName();
            this.show_deposit.Content = (acc_1.returnDeposit()).ToString();

        }

       
    }
}
